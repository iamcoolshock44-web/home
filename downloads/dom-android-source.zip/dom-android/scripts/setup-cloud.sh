#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
source scripts/cloud-env.sh
mkdir -p "$DOM_TOOLS_DIR/downloads" "$ANDROID_USER_HOME/cache" "$GRADLE_USER_HOME" "$ANDROID_EMULATOR_HOME" "$ANDROID_AVD_HOME"

if [[ ! -x "$JAVA_HOME/bin/javac" ]]; then
  jdk_base='https://github.com/adoptium/temurin21-binaries/releases/download/jdk-21.0.8%2B9/OpenJDK21U-jdk_x64_linux_hotspot_21.0.8_9.tar.gz'
  curl -fsSL --retry 2 "$jdk_base.sha256.txt" -o "$DOM_TOOLS_DIR/downloads/jdk.sha256"
  curl -fsSL --retry 2 "$jdk_base" -o "$DOM_TOOLS_DIR/downloads/jdk.tar.gz"
  python3 - <<'PY'
import hashlib, os, pathlib
p = pathlib.Path(os.environ['DOM_TOOLS_DIR']) / 'downloads'
expected = (p / 'jdk.sha256').read_text().split()[0]
assert hashlib.sha256((p / 'jdk.tar.gz').read_bytes()).hexdigest() == expected, 'JDK checksum mismatch'
PY
  mkdir -p "$JAVA_HOME"
  tar -xzf "$DOM_TOOLS_DIR/downloads/jdk.tar.gz" -C "$JAVA_HOME" --strip-components=1
fi

if [[ ! -x "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" ]]; then
  curl -fsSL --retry 2 https://dl.google.com/android/repository/commandlinetools-linux-13114758_latest.zip -o "$DOM_TOOLS_DIR/downloads/android-tools.zip"
  # Published checksum from Google's repository2-1.xml for cmdline-tools 19.0.
  python3 - <<'PY'
import hashlib, os, pathlib
p = pathlib.Path(os.environ['DOM_TOOLS_DIR']) / 'downloads/android-tools.zip'
assert hashlib.sha1(p.read_bytes()).hexdigest() == '5fdcc763663eefb86a5b8879697aa6088b041e70', 'Android tools checksum mismatch'
PY
  mkdir -p "$ANDROID_HOME/cmdline-tools"
  unzip -q "$DOM_TOOLS_DIR/downloads/android-tools.zip" -d "$ANDROID_HOME/cmdline-tools"
  mv "$ANDROID_HOME/cmdline-tools/cmdline-tools" "$ANDROID_HOME/cmdline-tools/latest"
fi

# Reuse the platform HTTPS proxy; do not store or inspect authentication values.
python3 - <<'PY'
import os, pathlib, urllib.parse, subprocess
u = urllib.parse.urlsplit(os.environ.get('HTTPS_PROXY', ''))
p = pathlib.Path(os.environ['GRADLE_USER_HOME']) / 'gradle.properties'
lines = p.read_text().splitlines() if p.exists() else []
updates = {'org.gradle.jvmargs': '-Xmx1536m -Dfile.encoding=UTF-8 -Duser.home=' + os.environ['DOM_TOOLS_DIR'] + '/java-user'}
if u.hostname:
    for protocol in ('http', 'https'):
        updates['systemProp.' + protocol + '.proxyHost'] = u.hostname
        updates['systemProp.' + protocol + '.proxyPort'] = str(u.port or 80)
    updates['systemProp.http.nonProxyHosts'] = 'localhost|127.*'
lines = [line for line in lines if line.split('=', 1)[0] not in updates]
p.write_text('\n'.join(lines + [k + '=' + v for k, v in updates.items()]) + '\n')
base = [os.environ['ANDROID_HOME'] + '/cmdline-tools/latest/bin/sdkmanager', '--sdk_root=' + os.environ['ANDROID_HOME']]
if u.hostname:
    base += ['--proxy=http', '--proxy_host=' + u.hostname, '--proxy_port=' + str(u.port or 80)]
subprocess.run(base + ['--licenses'], input='y\n' * 100, text=True, check=True)
subprocess.run(base + ['platforms;android-35', 'build-tools;35.0.0', 'platform-tools'], input='y\n' * 100, text=True, check=True)
PY
if [[ ! -e local.properties ]]; then
  printf 'sdk.dir=%s\n' "$ANDROID_HOME" > local.properties
fi
npm ci --ignore-scripts --no-audit --no-fund
if [[ -z "${CHROMIUM_PATH:-}" ]]; then
  export PLAYWRIGHT_BROWSERS_PATH="$DOM_TOOLS_DIR/playwright-browsers"
  npx playwright install chromium
fi
./gradlew :app:assembleDebug :app:lintDebug --no-daemon --console=plain
npm test
