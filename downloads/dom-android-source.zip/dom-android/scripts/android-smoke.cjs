// Native integration check through the debug WebView's local DevTools endpoint.
// Node.js 22+ is required for the built-in WebSocket API.
const { execFileSync } = require('node:child_process');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const adbPath = process.env.ADB_PATH || 'adb';
const args = process.env.ANDROID_SERIAL ? ['-s', process.env.ANDROID_SERIAL] : [];
const adb = (...command) => execFileSync(adbPath, [...args, ...command], { encoding: 'utf8', timeout: 60000 }).trim();
const pause = ms => new Promise(resolve => setTimeout(resolve, ms));
const origin = 'http://127.0.0.1:9223';
let socket;
let sequence = 0;
const pending = new Map();

async function connect() {
  const deadline = Date.now() + 150000;
  for (let attempt = 0; attempt < 90; attempt++) {
    try {
      const pid = adb('shell', 'pidof', 'com.domplanner.app');
      if (!pid) throw new Error('App has not started yet');
      adb('forward', 'tcp:9223', `localabstract:webview_devtools_remote_${pid}`);
      const response = await fetch(`${origin}/json/list`, { signal: AbortSignal.timeout(3000) });
      const targets = await response.json();
      const target = targets.find(t => t.type === 'page' && t.url === 'file:///android_asset/index.html');
      if (!target) throw new Error('Waiting for the app page');
      socket = new WebSocket(target.webSocketDebuggerUrl);
      await new Promise((resolve, reject) => {
        const timer = setTimeout(() => reject(new Error('WebView debugger connection timed out')), 15000);
        socket.addEventListener('open', () => { clearTimeout(timer); resolve(); }, { once: true });
        socket.addEventListener('error', error => { clearTimeout(timer); reject(error); }, { once: true });
      });
      socket.addEventListener('message', event => {
        const message = JSON.parse(event.data);
        const callback = pending.get(message.id);
        if (!callback) return;
        pending.delete(message.id);
        clearTimeout(callback.timer);
        if (message.error) callback.reject(new Error(message.error.message));
        else callback.resolve(message.result);
      });
      await command('Runtime.enable', {});
      await waitFor('Boolean(window.DomApp)');
      return;
    } catch (error) {
      socket?.close();
      if (attempt === 89 || Date.now() >= deadline) throw error;
      await pause(1000);
    }
  }
}

function command(method, params) {
  return new Promise((resolve, reject) => {
    const id = ++sequence;
    const timer = setTimeout(() => {
      pending.delete(id);
      reject(new Error(`DevTools timed out: ${method}`));
    }, 15000);
    pending.set(id, { resolve, reject, timer });
    socket.send(JSON.stringify({ id, method, params }));
  });
}
async function evaluate(expression) {
  const result = await command('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true });
  if (result.exceptionDetails) throw new Error(result.exceptionDetails.text);
  return result.result.value;
}
async function waitFor(expression) {
  for (let attempt = 0; attempt < 60; attempt++) {
    if (await evaluate(expression)) return;
    await pause(500);
  }
  throw new Error(`Android check timed out: ${expression}`);
}
function wakeAndStart() {
  adb('shell', 'input', 'keyevent', '224');
  adb('shell', 'wm', 'dismiss-keyguard');
  adb('shell', 'am', 'start', '-n', 'com.domplanner.app/.MainActivity');
}

(async () => {
  assert.equal(adb('shell', 'getprop', 'sys.boot_completed'), '1', 'Boot the development device first');
  adb('install', '-r', path.resolve(__dirname, '../app/build/outputs/apk/debug/app-debug.apk'));
  console.log('APK installed.');
  wakeAndStart();
  await connect();
  console.log('Android WebView loaded.');
  assert.equal(await evaluate('document.title'), 'Дом');
  await evaluate("createProject(); projectData.name='Android smoke test'; syncProjectCard(); show('m-home'); DomApp.save(); projectSettings(); true");
  adb('shell', 'input', 'keyevent', '4');
  await waitFor("modalBg.classList.contains('hidden')");
  assert.equal(await evaluate('current'), 'm-home');
  fs.mkdirSync(path.resolve(__dirname, '../artifacts'), { recursive: true });
  fs.writeFileSync(path.resolve(__dirname, '../artifacts/dom-android.png'),
    execFileSync(adbPath, [...args, 'exec-out', 'screencap', '-p'], { timeout: 60000 }));
  socket.close();
  adb('shell', 'am', 'force-stop', 'com.domplanner.app');
  wakeAndStart();
  await connect();
  assert.deepEqual(await evaluate('[created, projectData.name]'), [true, 'Android smoke test']);
  assert.equal(await evaluate("!document.getElementById('homeProjectState').classList.contains('hidden')"), true);
  console.log('PASS: Android launch, packaged UI, native Back, and persistence after force-stop.');
})().catch(error => { console.error(error); process.exitCode = 1; }).finally(() => {
  socket?.close();
  for (const callback of pending.values()) clearTimeout(callback.timer);
  try { adb('forward', '--remove', 'tcp:9223'); } catch (_) {}
});
