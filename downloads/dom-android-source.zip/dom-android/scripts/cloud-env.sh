#!/usr/bin/env bash
# Source this file in the isolated Codex cloud machine before building.
export DOM_TOOLS_DIR="${DOM_TOOLS_DIR:-/workspace/tooling}"
export JAVA_HOME="$DOM_TOOLS_DIR/jdk"
export ANDROID_HOME="$DOM_TOOLS_DIR/android-sdk"
export ANDROID_USER_HOME="$DOM_TOOLS_DIR/android-user"
export ANDROID_EMULATOR_HOME="$DOM_TOOLS_DIR/emulator-home"
export ANDROID_AVD_HOME="$DOM_TOOLS_DIR/avd"
export GRADLE_USER_HOME="$DOM_TOOLS_DIR/gradle-home"
export npm_config_cache="$DOM_TOOLS_DIR/npm-cache"
export PLAYWRIGHT_BROWSERS_PATH="$DOM_TOOLS_DIR/playwright-browsers"
export PATH="$JAVA_HOME/bin:$ANDROID_HOME/platform-tools:$ANDROID_HOME/cmdline-tools/latest/bin:$PATH"
if [[ -f /etc/ssl/certs/java/cacerts ]]; then
  export JAVA_TOOL_OPTIONS="${JAVA_TOOL_OPTIONS:+$JAVA_TOOL_OPTIONS }-Djavax.net.ssl.trustStore=/etc/ssl/certs/java/cacerts"
fi
if command -v chromium >/dev/null 2>&1; then
  export CHROMIUM_PATH="$(command -v chromium)"
fi
