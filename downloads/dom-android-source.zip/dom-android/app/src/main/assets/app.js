/* Android/offline integration. Prototype functions remain the UI implementation. */
(() => {
  'use strict';
  const STORAGE_KEY = 'dom.offline.v1';
  const defaults = JSON.parse(JSON.stringify(projectData));
  const defaultTeam = JSON.parse(JSON.stringify(teamMembers));
  const formSelector = '#m-known-house input[id], #m-known-house select[id], #m-known-house textarea[id], #m-land input[id]';
  const defaultForms = Object.fromEntries(Array.from(document.querySelectorAll(formSelector), input => [input.id, input.value]));
  let teamChats = {};
  let saveWarningShown = false;
  const object = value => value && typeof value === 'object' && !Array.isArray(value);
  const stableScreens = new Set([
    'm-discover', 'm-services', 'm-home', 'm-profile', 'm-myhouse',
    'm-budget', 'm-docs', 'm-requests', 'm-project-entry', 'm-known-house', 'm-quiz'
  ]);

  function snapshot() {
    const forms = {};
    document.querySelectorAll(formSelector)
      .forEach(input => { forms[input.id] = input.value; });
    return {
      version: 1, created, projectData, state, q, applications, appSeq,
      teamActive: Object.fromEntries(Object.entries(teamMembers).map(([id, member]) => [id, member.active])),
      teamChats, assistantMessages, knownHouseMode, knownHouseRegion, forms,
      screen: stableScreens.has(current) ? current : (created ? 'm-home' : 'm-discover')
    };
  }

  function save() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(snapshot()));
      return true;
    } catch (error) {
      if (!saveWarningShown) {
        saveWarningShown = true;
        toast('Не удалось сохранить данные. Освободите место на устройстве.');
      }
      return false;
    }
  }

  function restore() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return;
      const data = JSON.parse(raw);
      if (data.version !== 1 || !object(data.projectData) || !Array.isArray(data.applications)) {
        throw new Error('Unsupported saved data');
      }
      // Only known project fields are restored; preserve numeric strings used by the UI.
      for (const key of Object.keys(defaults)) {
        if (typeof data.projectData[key] === 'string') projectData[key] = data.projectData[key];
      }
      created = data.created === true;
      applications = data.applications.filter(a => object(a) && typeof a.id === 'string'
        && /^ЗАЯВКА-\d+$/.test(a.id) && Array.isArray(a.responseIds) && object(a.chats));
      const largestId = Math.max(1042, ...applications.map(a => Number(a.id.split('-')[1])));
      appSeq = Number.isInteger(data.appSeq) ? Math.max(data.appSeq, largestId) : largestId;
      if (object(data.state)) state = data.state;
      q = Number.isInteger(data.q) && data.q >= 0 && data.q < qs.length ? data.q : 0;
      knownHouseMode = data.knownHouseMode === true;
      knownHouseRegion = typeof data.knownHouseRegion === 'string' ? data.knownHouseRegion : '';
      if (object(data.teamActive)) {
        for (const [id, member] of Object.entries(teamMembers)) {
          if (typeof data.teamActive[id] === 'boolean') member.active = data.teamActive[id];
        }
      }
      if (object(data.teamChats)) teamChats = data.teamChats;
      if (Array.isArray(data.assistantMessages)) {
        assistantMessages = data.assistantMessages.filter(m => object(m) && typeof m.text === 'string');
      }
      if (object(data.forms)) {
        for (const [id, value] of Object.entries(data.forms)) {
          const input = document.getElementById(id);
          if (input && input.matches('input, select, textarea') && typeof value === 'string') input.value = value;
        }
      }
      syncKnownHouseForm();
      syncProjectCard();
      syncProjectStateUI();
      mCenterText.textContent = created ? 'Мой дом' : 'Начать';
      mCenterIcon.textContent = created ? '⌂' : '＋';
      const screen = stableScreens.has(data.screen) && document.getElementById(data.screen)
        ? data.screen : 'm-discover';
      if (screen === 'm-quiz') renderQ();
      hist = screen === 'm-discover' ? ['m-discover'] : ['m-discover', screen];
      show(screen, { back: true });
    } catch (error) {
      // Never silently overwrite malformed or newer saved data on initial load.
      toast('Сохранённые данные не удалось прочитать. Можно начать новый проект.');
    }
  }

  // Save immediately after meaningful mutations, including calls outside click handlers.
  const mutations = [
    'createProject', 'saveKnownHouseParams', 'saveLandAndContinue', 'chooseLand', 'chooseHouse',
    'saveProjectSettings', 'createDirectRequest', 'createOpenRequest', 'chooseResponse',
    'sendApplicationChat', 'removeTeamMember', 'sendAssistantMessage', 'sendOperatorMessage'
  ];
  for (const name of mutations) {
    const original = window[name];
    window[name] = function (...args) {
      const result = original.apply(this, args);
      save();
      return result;
    };
  }

  const originalDelete = window.deleteProject;
  window.deleteProject = function () {
    originalDelete();
    Object.assign(projectData, defaults);
    for (const id of Object.keys(teamMembers)) Object.assign(teamMembers[id], defaultTeam[id]);
    teamChats = {};
    state = { region: '', areaFrom: 120, areaTo: 160 };
    q = 0;
    knownHouseRegion = '';
    for (const [id, value] of Object.entries(defaultForms)) document.getElementById(id).value = value;
    syncKnownHouseForm();
    appSeq = 1042;
    syncProjectCard();
    syncProjectStateUI();
    save();
  };

  // The prototype's team chat only displayed a toast. Keep real local conversations.
  window.openChat = function (id) {
    const member = teamMembers[id];
    if (!member) return;
    currentMemberId = id;
    const messages = teamChats[id] || [];
    sheetModal(`<span class="tag">Локальный демо-чат</span><h2>${escapeHtml(member.name)}</h2>
      <div class="chatBox" id="teamChatBox">
        <div class="chatBubble them">Это демо-чат. Сообщения сохраняются только на вашем устройстве.</div>
        ${messages.map(text => `<div class="chatBubble me">${escapeHtml(text)}</div>`).join('')}
      </div>
      <div class="field"><input id="chatMessage" placeholder="Сообщение подрядчику"
        onkeydown="if(event.key==='Enter')sendChat()"></div>
      <button class="btn dark wide" onclick="sendChat()">Отправить</button>
      <button class="btn ghost wide" style="margin-top:8px" onclick="closeModal()">Закрыть</button>`);
    const box = document.getElementById('teamChatBox');
    box.scrollTop = box.scrollHeight;
  };
  window.sendChat = function () {
    const value = document.getElementById('chatMessage')?.value.trim();
    if (!value) { toast('Введите сообщение'); return; }
    (teamChats[currentMemberId] ||= []).push(value);
    openChat(currentMemberId);
    save();
  };

  // Keep support honest in an offline build; no external operator is contacted.
  window.callOperator = function () {
    sheetModal(`<span class="tag">Офлайн-версия</span><h2>Поддержка</h2>
      <p class="muted">Связь с оператором появится после подключения сервера.
      Сейчас доступен локальный помощник с готовыми ответами.</p>
      <button class="btn dark wide" onclick="openAssistant()">Вернуться к помощнику</button>
      <button class="btn ghost wide" style="margin-top:8px" onclick="closeModal()">Закрыть</button>`);
  };

  function back() {
    if (!modalBg.classList.contains('hidden')) { closeModal(); save(); return true; }
    if (current === 'm-quiz' && q > 0) { prevQ(); save(); return true; }
    if (hist.length > 1 || current !== 'm-discover') { goBack(); save(); return true; }
    save();
    return false;
  }
  window.DomApp = Object.freeze({ save, back });
  document.addEventListener('click', () => setTimeout(save, 0));
  document.addEventListener('change', save);
  document.addEventListener('input', save);
  document.addEventListener('visibilitychange', () => { if (document.hidden) save(); });
  window.addEventListener('pagehide', save);
  window.addEventListener('keydown', event => {
    if (event.key === 'Escape') { back(); event.preventDefault(); }
  });
  document.getElementById('toast').setAttribute('role', 'status');
  document.getElementById('sheet').setAttribute('role', 'dialog');
  document.getElementById('sheet').setAttribute('aria-label', 'Диалог');
  document.getElementById('back').setAttribute('aria-label', 'Назад');

  // Hide the floating navigation while an input is being edited on a small viewport.
  const updateKeyboard = () => {
    const editing = document.activeElement?.matches('input, textarea, select');
    const reduced = window.visualViewport && window.visualViewport.height < window.innerHeight * 0.78;
    document.body.classList.toggle('keyboardOpen', Boolean(editing || reduced));
  };
  document.addEventListener('focusin', updateKeyboard);
  document.addEventListener('focusout', () => setTimeout(updateKeyboard, 0));
  window.visualViewport?.addEventListener('resize', updateKeyboard);
  restore();
})();
