# Дом — offline Android app

An Android app based on the supplied Russian house-building prototype. The UI
runs from packaged HTML, CSS, and JavaScript in an Android WebView, preserving
the original screens and illustrations. A Java activity handles Android Back,
system bars, keyboard space, and the app lifecycle. Android 8.0 (API 26) or newer,
with an up-to-date Android System WebView.

## Included

- House questionnaire and approximate cost calculation.
- Custom house parameters, land and house catalogs, project stages and dashboard.
- Demo contractor requests, selection, and locally saved conversations.
- Local assistant with predefined answers.
- Project, questionnaire, request, and chat persistence across restarts.
- Project deletion, safe rendering of typed text, and offline-only asset loading.

This is an **offline first version**. Catalogs, prices, profile, progress, budget
forecasts, documents, and contractor replies are sample data from the prototype.
Requests are not sent to contractors. There are no real accounts, payments,
document uploads, support operator, or remote AI. No Internet permission is
requested. Clearing app storage or uninstalling removes local data.

## Build and install

Open this folder in Android Studio, using JDK 17 or 21. Install Android SDK 35
and Build Tools 35.0.0. Android Studio creates an ignored `local.properties` with
your SDK path. Alternatively, set `ANDROID_HOME` and run:

```sh
./gradlew :app:assembleDebug :app:lintDebug
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

The debug APK is installable on a device but is not a Play Store release.
Release signing and store publication are separate steps.

## UI tests

Node.js 20+ is needed only for development tests, not for the Android app.

```sh
npm ci
npx playwright install chromium
npm test
```

Set `CHROMIUM_PATH` to an existing Chromium executable to reuse it. The eight
browser tests cover project creation, questionnaire restoration and estimates,
requests and chats, persistence, text escaping, deletion, mobile layout, and
the Back contract. They run the same assets that are packaged in the APK.
Android build and lint separately check the native shell.

With Node.js 22+ and a booted Android device or emulator connected, run
`npm run test:android`.
Set `ANDROID_SERIAL` when more than one device is connected. This smoke test
installs the debug APK, creates a sample project named “Android smoke test”,
checks the hardware Back behavior, force-stops and restarts the app, and verifies
that the project survives. It captures `artifacts/dom-android.png`. It changes
only this app's local data on the chosen device, so use a development device.

## Codex cloud environment

Use the existing `/workspace/home` checkout; each task is already isolated and
does not need a Git worktree. Run `bash scripts/setup-cloud.sh` to install the
pinned JDK and Android SDK, configure proxy and system CA trust, install test
dependencies, build the APK, and run validation. Tools and caches live outside
the repository under `/workspace/tooling`. The script accepts Android SDK
licenses for those development tools. Re-running uses installed tools and
frozen npm dependencies without changing source or lockfiles.

For later tasks with the prepared filesystem:

```sh
cd /workspace/home
source scripts/cloud-env.sh
./gradlew :app:assembleDebug :app:lintDebug --no-daemon
npm test
```

No server or credentials are needed to run the app. Open it on a connected
Android device or emulator. Live emulator processes must be restarted in a new
task; the environment snapshot retains files, not running processes.

## Files

- `prototype/dom_prototype_mobile_v8.html`: unmodified uploaded reference.
- `app/src/main/assets/`: adapted UI, local storage, and mobile adjustments.
- `app/src/main/java/com/domplanner/app/MainActivity.java`: Android shell.
- `tests/offline.test.cjs`: functional browser tests.

The cloud-tested Gradle version is 8.13 and Android Gradle Plugin is 8.11.1.
The wrapper verifies the Gradle distribution's SHA-256 checksum. Download and
TLS verification remain enabled for all setup tools.

See `VALIDATION.md` for the checks that passed and the remaining native device
check. Cloud emulator validation did not complete; a real device check is still
needed before calling this version device-validated.
