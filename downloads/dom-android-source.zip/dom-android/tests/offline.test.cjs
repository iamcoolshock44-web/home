const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { chromium } = require('playwright');

const assets = path.resolve(__dirname, '../app/src/main/assets');
let server, browser, origin;
before(async () => {
  server = http.createServer((request, response) => {
    const filename = new URL(request.url, 'http://localhost').pathname;
    const allowed = { '/': 'index.html', '/index.html': 'index.html', '/app.js': 'app.js', '/android.css': 'android.css' };
    if (!allowed[filename]) { response.writeHead(404).end(); return; }
    response.setHeader('Content-Type', filename.endsWith('.js') ? 'application/javascript' : filename.endsWith('.css') ? 'text/css' : 'text/html');
    fs.createReadStream(path.join(assets, allowed[filename])).pipe(response);
  });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  origin = `http://127.0.0.1:${server.address().port}`;
  browser = await chromium.launch({
    executablePath: process.env.CHROMIUM_PATH || undefined,
    headless: true,
    args: ['--no-sandbox']
  });
});
after(async () => {
  if (browser) await browser.close();
  if (server) await new Promise(resolve => server.close(resolve));
});

async function app(t, width = 393) {
  const context = await browser.newContext({ viewport: { width, height: 852 }, isMobile: true, hasTouch: true });
  const page = await context.newPage();
  const errors = [];
  const requests = [];
  page.on('pageerror', error => errors.push(error.message));
  page.on('request', request => requests.push(request.url()));
  t.after(async () => {
    assert.deepEqual(errors, [], 'No JavaScript errors');
    assert.ok(requests.every(url => url.startsWith(origin)), 'All app assets and behavior stay offline');
    await context.close();
  });
  await page.goto(origin);
  await page.waitForFunction(() => Boolean(window.DomApp));
  return page;
}

test('launch, tabs, empty project, and mobile layout', async t => {
  const page = await app(t, 360);
  assert.equal(await page.title(), 'Дом');
  assert.ok(await page.getByText('Офлайн-демо', { exact: false }).isVisible());
  await page.locator('.nav[data-id="m-home"]').click();
  assert.ok(await page.locator('#homeEmptyState').isVisible());
  await page.locator('.nav[data-id="m-profile"]').click();
  assert.equal(await page.locator('#profileRequestsCount').textContent(), '0');
  assert.ok(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth));
});

test('known-house flow creates and restores a project and form drafts', async t => {
  const page = await app(t);
  await page.locator('#mCenter').click();
  await page.locator('[onclick="startKnownHouseFlow()"] ').click();
  await page.locator('#knownRegionButton').click();
  await page.locator('#knownRegionSearch').fill('Татар');
  await page.getByRole('button', { name: 'Республика Татарстан', exact: true }).click();
  await page.locator('#knownArea').fill('180');
  await page.locator('#knownMustHave').fill('Кабинет и терраса');
  await page.getByRole('button', { name: 'Сохранить параметры и продолжить' }).click();
  await page.locator('#m-start [onclick="show(\'m-land\')"]').click();
  await page.locator('#landAreaInput').fill('15');
  await page.locator('#landRegionInput').fill('Казань');
  await page.locator('[onclick="saveLandAndContinue()"] ').click();
  assert.equal(await page.evaluate(() => created), true);
  await page.reload();
  assert.deepEqual(await page.evaluate(() => [created, projectData.area, projectData.plot, projectData.region, projectData.mustHave]),
    [true, '180', '15', 'Казань', 'Кабинет и терраса']);
  await page.locator('.nav[data-id="m-home"]').click();
  assert.ok(await page.locator('#homeProjectState').isVisible());
  fs.mkdirSync(path.resolve(__dirname, '../artifacts'), { recursive: true });
  await page.screenshot({ path: path.resolve(__dirname, '../artifacts/dom-home.png') });
});

test('questionnaire validates region, saves progress, and calculates a result', async t => {
  const page = await app(t);
  await page.evaluate(() => startQuiz());
  await page.getByRole('button', { name: 'Далее →' }).click();
  assert.equal(await page.evaluate(() => q), 0);
  await page.locator('#m-quiz .region-trigger').click();
  await page.locator('#regionSearch').fill('Москва');
  await page.getByRole('button', { name: 'Москва', exact: true }).click();
  await page.getByRole('button', { name: 'Далее →' }).click();
  await page.getByRole('button', { name: 'Постоянное проживание', exact: true }).click();
  await page.getByRole('button', { name: 'Далее →' }).click();
  await page.reload();
  assert.equal(await page.evaluate(() => q), 2);
  assert.ok(await page.locator('#m-quiz').isVisible());
  await page.getByRole('button', { name: 'Далее →' }).click();
  await page.locator('.answer').nth(1).click();
  await page.getByRole('button', { name: 'Далее →' }).click();
  await page.locator('.answer').nth(2).click();
  await page.getByRole('button', { name: 'Далее →' }).click();
  await page.locator('.answer').nth(1).click();
  await page.getByRole('button', { name: 'Далее →' }).click();
  assert.ok(await page.locator('#m-result').isVisible());
  assert.match(await page.locator('#resultBudget').textContent(), /14.*700.*000/);
});

test('open requests, selection, escaped local messages, and persistence', async t => {
  const page = await app(t);
  await page.evaluate(() => service('Геология и геодезия'));
  await page.locator('#serviceParams input').first().fill('12 < 15');
  await page.evaluate(() => lead());
  const text = '<img src=x onerror="window.injected=true"> исследование';
  await page.locator('#leadText').fill(text);
  await page.getByRole('button', { name: 'Опубликовать заявку' }).click();
  assert.equal(await page.evaluate(() => applications.length), 1);
  assert.equal(await page.locator('#requestDetailContent .card p').first().textContent(), text);
  assert.equal(await page.locator('#requestDetailContent img').count(), 0);
  await page.locator('.responseActions .primary').first().click();
  await page.getByRole('button', { name: 'Связаться с подрядчиком' }).click();
  await page.locator('#requestChatMessage').fill(text);
  await page.locator('#sheet').getByRole('button', { name: 'Отправить', exact: true }).click();
  assert.equal(await page.locator('.chatBubble.me').last().textContent(), text);
  await page.reload();
  await page.evaluate(() => openRequestDetail(applications[0].id));
  await page.getByRole('button', { name: 'Связаться с подрядчиком' }).click();
  assert.equal(await page.locator('.chatBubble.me').last().textContent(), text);
  assert.equal(await page.evaluate(() => window.injected), undefined);
});

test('direct contractor request and team chat work without a server', async t => {
  const page = await app(t);
  await page.evaluate(() => { service('Проектирование'); openContractors(); });
  // Catalog identifiers are discovered rather than inventing a contractor.
  await page.evaluate(() => contractor(contractorCatalog['Проектирование'][0].id));
  await page.getByRole('button', { name: 'Выбрать подрядчика', exact: true }).click();
  assert.equal(await page.evaluate(() => applications[0].mode), 'direct');
  await page.evaluate(() => { closeModal(); openChat('architect'); });
  await page.locator('#chatMessage').fill('Согласуем планировку завтра');
  await page.locator('#sheet').getByRole('button', { name: 'Отправить', exact: true }).click();
  await page.reload();
  await page.evaluate(() => openChat('architect'));
  assert.equal(await page.locator('.chatBubble.me').last().textContent(), 'Согласуем планировку завтра');
});

test('project edits render input as text, deletion clears persisted project data', async t => {
  const page = await app(t);
  await page.evaluate(() => { createProject(); editProjectSettings(); });
  const name = 'Дом "Семья" <b>тест</b>';
  await page.locator('#editProjectName').fill(name);
  await page.getByRole('button', { name: 'Сохранить изменения' }).click();
  await page.evaluate(() => { projectSettings(); editProjectSettings(); });
  assert.equal(await page.locator('#editProjectName').inputValue(), name);
  await page.evaluate(() => { closeModal(); service('Проектирование'); createDirectRequest(contractorCatalog['Проектирование'][0].id); deleteProject(); });
  await page.reload();
  assert.deepEqual(await page.evaluate(() => [created, applications.length, projectData.name, teamMembers.architect.active]),
    [false, 0, 'Дом в Истре', true]);
});

test('Android Back contract closes dialogs, revisits quiz steps, and exits only at root', async t => {
  const page = await app(t);
  assert.equal(await page.evaluate(() => DomApp.back()), false);
  await page.evaluate(() => { show('m-services'); lead(); });
  assert.equal(await page.evaluate(() => DomApp.back()), true);
  assert.ok(await page.locator('#modalBg').evaluate(node => node.classList.contains('hidden')));
  assert.equal(await page.evaluate(() => DomApp.back()), true);
  assert.equal(await page.evaluate(() => current), 'm-discover');
  await page.evaluate(() => { startQuiz(); q = 2; renderQ(); });
  assert.equal(await page.evaluate(() => DomApp.back()), true);
  assert.equal(await page.evaluate(() => q), 1);
});

test('unreadable saved data does not crash or get silently overwritten during launch', async t => {
  const page = await app(t);
  await page.addInitScript(() => localStorage.setItem('dom.offline.v1', '{broken'));
  await page.reload();
  assert.equal(await page.evaluate(() => localStorage.getItem('dom.offline.v1')), '{broken');
  assert.equal(await page.evaluate(() => created), false);
  assert.match(await page.locator('#toast').textContent(), /не удалось прочитать/);
});
