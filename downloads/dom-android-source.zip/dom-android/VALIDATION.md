# Validation in the cloud environment

- Android debug build: passed with Gradle 8.13, Android Gradle Plugin 8.11.1,
  Java 21, SDK 35, and Build Tools 35.0.0.
- Android lint: passed with zero errors. Remaining warnings concern newer SDK
  versions, optional newer platform attributes, JavaScript use, and backup rules.
- UI functional tests: **8 passed, 0 failed**. They exercised project creation,
  questionnaire progress and estimates, contractor requests, local chats,
  persistence, escaped input, deletion, mobile layout, and Back behavior.
- APK signature: verified, Android APK Signature Scheme v2.
- APK installation on the Android 15 emulator: passed.
- Native smoke test: **not completed**. The cloud machine has no `/dev/kvm`.
  Its software emulator showed System UI hangs and graphics errors; retrying
  with the supported software renderer allowed installation but the WebView
  debugger still timed out at `Runtime.enable`. App interaction and persistence
  after Android force-stop have therefore **not been verified on a device**.

For the remaining check, install the APK on an Android development device with
an up-to-date System WebView. Run `npm run test:android` (Node.js 22+) with
`ANDROID_SERIAL` set, or manually create a project, close/reopen the app, and
check that it is retained. Check Android Back closes dialogs before navigating.

The original uploaded prototype is retained unchanged. The repository's
original `first` file is unchanged. No backend or production signing is included.
